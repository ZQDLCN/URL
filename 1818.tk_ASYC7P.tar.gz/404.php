﻿
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh" lang="zh">
    <head>
        <title>404 - 页面未找到</title>
        <base href="<?php echo $info['URL']; ?>/" />
        <meta charset="utf-8">
        <meta name=keywords content="免费网址缩短,链接高速转发、超长链接缩短，短链加密，自定义短链，短链二维码，短链访问统计，免费短链API，免费二维码API，二维码API调用，个人二维码API搭建，短链平台，高防短链，链接跳转">
        <meta name=description content="免责声明：本站永久免费! 专门提供带统计的短网址服务，短网址均由用户生成，所跳转网站内容均与本站无关! ">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="icon" href="/img/logo.png" />
        <meta name='twitter:url' content='<?php echo $info["URL"]; ?>'>
        <meta name='twitter:title' content='<?php echo $info['name']; ?>'>
        <meta property="og:title" content="<?php echo $info['name']; ?>">
    </head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <style type="text/css">
        body {
            text-align: center;
            font-family: Arial;
            padding-top: 200px;
        }
    </style>
    <body>
        <h1>错误: 404</h1><b>页面未找到</b><br />抱歉，我们在您输入的网址上找不到任何内容。该页面可能以前已存在但不再有效。</body>
</html>