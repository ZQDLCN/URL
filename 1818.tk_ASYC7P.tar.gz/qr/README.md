# QrCodeApi
单文件实现的PHP二维码API

# 详细介绍
见：https://yantuz.cn/567.html
