<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html class="full" xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width">
        <title>请输入密码访问链接 - <?php echo $info['name']; ?></title>
                <meta charset="utf-8">
        <title><?php echo $info['name']; ?>-免费网址缩短，本站永久免费!</title>
        <meta name=keywords content="免费网址缩短,链接高速转发、超长链接缩短，短链加密，自定义短链，短链二维码，短链访问统计，免费短链API，免费二维码API，二维码API调用，个人二维码API搭建，短链平台，高防短链，链接跳转">
        <meta name=description content="免责声明：本站永久免费! 专门提供带统计的短网址服务，短网址均由用户生成，所跳转网站内容均与本站无关! ">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="icon" href="/img/logo.png" />
        <meta name='twitter:url' content='<?php echo $info["URL"]; ?>'>
        <meta name='twitter:title' content='<?php echo $info['name']; ?>'>
        <meta property="og:title" content="<?php echo $info['name']; ?>">
        <base href="<?php echo $info['URL']; ?>/" />
        <link href="font/css/font-awesome.min.css" rel="stylesheet">
        <link href="https://fonts.loli.net/css?family=Fjalla+One" rel="stylesheet">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <style>
            <?php echo $info['cstm-style']; ?>
        </style>
    </head>


    <body>
        <?php 
            include "functions/menu.php";
        ?>
        <div class="container">
            <div class="row logo">
                <div class="col-lg-12" style="text-align:center">
                    <?php 
                        include "functions/logo.php";
                    ?>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row" style="margin-top:20px">
                <div class="modal-dialog">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title" id="contactLabel"><span class="fa fa-lock"></span>请输入密码访问链接</h4>
                        </div>
                        <div class="modal-body">
                            <form name="form" method="post" action="<?php echo $shr; ?>">
                                <div class="form-group" >
                                    <div class="input-group">
                                        <input type="password" name="txtpass" placeholder=" 请输入密码" class="form-control">
                                        <span class="input-group-addon">
                                            <i class="fa fa-lock form-control-feedback"></i>
                                        </span>
                                    </div>
                                </div> 
                                <input type="submit" name="submit" id="submit" value="确定" class="btn btn-info ">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script src="js/jquery-1.10.2.js"></script>
        <script src="js/bootstrap.js"></script>

    </body>
</html>



