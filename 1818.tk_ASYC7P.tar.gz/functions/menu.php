<nav class="navbar navbar-fixed-top navbar-inverse" role="navigation">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="/">
                <?php echo $info['name']; ?></a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse navbar-ex1-collapse">
            <ul class="nav navbar-nav">
                <li><a href="/">首页</a></li>
                <li><a href="tos">使用许可</a></li>
                <li><a href="api-about">API接口</a></li>
                <li><a href="apiqr.php">二维码API接口</a></li>
                <li><a href="https://zqdlcn.tk" target="_blank">免费图床</a></li>
                <li><a href="contact">联系我们</a></li>
                <li><a href="about">关于我们</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li class="active"><a href="statics.php">链接统计</a></li>
                <li class="active"><a href="xiazai.php">本站源码</a></li>
            </ul>
        </div>
        <!-- /.navbar-collapse -->
    </div>
    <!-- /.container -->
</nav>

<script>
    const bookmarklet = () => {
        alert("Here I am!")
    }
</script>
<nav class="navbar navbar-fixed-bottom navbar-inverse" role="navigation">
<p class="footer" style="text-align: center;">
</p>
<p style="text-align: center;">
<?php
            include "functions/dibu.php";
        ?>
</p>
</nav>
<script></script>
<script></script>