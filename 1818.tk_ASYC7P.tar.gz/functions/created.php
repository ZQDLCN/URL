﻿<!DOCTYPE html>
<html class="full" lang="zh">

    <head>
	    <base href="<?php echo $info['URL']; ?>/" />
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>网址已成功缩短 - <?php echo $info['name']; ?></title>
                <meta charset="utf-8">
        <title><?php echo $info['name']; ?>-免费网址缩短，本站永久免费!</title>
        <meta name=keywords content="免费网址缩短,链接高速转发、超长链接缩短，短链加密，自定义短链，短链二维码，短链访问统计，免费短链API，免费二维码API，二维码API调用，个人二维码API搭建，短链平台，高防短链，链接跳转">
        <meta name=description content="免责声明：本站永久免费! 专门提供带统计的短网址服务，短网址均由用户生成，所跳转网站内容均与本站无关! ">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="icon" href="/img/logo.png" />
        <meta name='twitter:url' content='<?php echo $info["URL"]; ?>'>
        <meta name='twitter:title' content='<?php echo $info['name']; ?>'>
        <meta property="og:title" content="<?php echo $info['name']; ?>">

        <!-- Bootstrap core CSS -->
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/animate.css" rel="stylesheet">

        <!-- Custom CSS for the Template -->
        <link href="css/style.css" rel="stylesheet">

        <link href="https://fonts.loli.net/css?family=Fjalla+One" rel="stylesheet">
        
        <style>
            a { color: inherit; }
        </style>
        <style>
            <?php echo $info['cstm-style']; ?>
        </style>
    </head>

    <body>

        <?php
            include "functions/menu.php";
        ?>
        <div class="container" style="margin-top: -20px;">
        <div class="row logo">
            <div class="col-lg-12" style="text-align:center">
                <?php 
                    include "functions/logo.php";
                    include "functions/darkmode.php";
                ?>
            </div>
        </div>
        </div>
        <div class="container animated fadeIn">

            <div class="row">
                <div class="col-lg-10 col-lg-offset-1" style="margin-bottom: -25px;">
                    <div class="alert alert-dismissable alert-default text-center">
                        <h4  style="margin-bottom: -4px; color: #707070;"> 短链接及二维码成功生成！ </h4> 
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="input-group">
                        <input id="urlbox" class="form-control cz-shorten-input" readonly name="url" value="<?php echo $created_link; ?>"  type="text">
                        <span class="input-group-btn">
                            <button class="btn btn-large btn-primary cz-shorten-btn" type="submit" id="copy-button">点我复制！！！</button>
                        </span>
                    </div>
                </div>
            </div>
            <div class="row" style="margin-top: 30px;">
                <div class="col-lg-4 text-center">
                    <div class="panel panel-success">
                        <div class="panel-heading">
                            <h3 class="panel-title newsize" style="font-weight:bolder;">短网址二维码</h3>
                        </div>
                        <div class="panel-body">
                            <img src="/qr/api.php?text=<?php echo $created_link; ?>&size=200"></p>
                            <a href="/qr/api.php?text=<?php echo $created_link; ?>&size=200" target="_blank"><h3 class="panel-title newsize" style="font-weight:bolder;">查看二维码地址</h3></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8 text-center">
                    <div class="row">
                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <h3 class="panel-title newsize" style="font-weight:bolder;">再次制作</h3>
                            </div>
                            <div class="panel-body">
                                <a href="/"><h3 class="panel-title newsize" style="font-weight:bolder;">点我再做一个呗！</h3></a>

                            </div>
                        </div>
                    </div>
                    <!-- row -->
                    <div class="row" style="margin-top: -4px;">
                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <h3 class="panel-title newsize" style="font-weight:bolder;">您的短链专属统计链接</h3>
                            </div>
                            <div class="panel-body">
                                <h4 style="margin-bottom: 20px; color: #707070;font-size: 20px;color: #ff0000;margin-top:10px;"> 这是你的专属短链统计页面链接请自行保存！ </h4>
                                <a style="color: #2296f3;"href="<?php echo $info['URL'] . '/stats.php?id=' . $rand1; ?>" target="_blank"> <h3>   <?php echo $info['URL'] . '/stats.php?id=' . $rand1; ?></h3></a>
                                <h2 style="margin-bottom: 16px; color: #707070;font-size: 24px;color: #ff0000;margin-top:28px;"> 严禁生成违法链接！一经发现直接删除！并举报违规链接！ </h2>
                            </div>
                        </div>
                    </div>
                    <!-- row -->
                </div>

            </div>
        </div>
        <!-- JavaScript -->
        <script src="js/jquery-1.10.2.js"></script>
        <script src="js/bootstrap.js"></script>
        <script type="text/javascript" src="js/jquery.zclip.min.js"></script>

        <script type="text/javascript">
            $(document).ready(function() {
                $("#copy-button").click(function () {
                    $(this).html("复制成功！！！");
                    $("#urlbox").select();
                    document.execCommand("copy");
                });
            });
        </script>
    </body>

</html>
