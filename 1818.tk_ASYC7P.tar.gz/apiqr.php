﻿<?php
include "functions/database.php";

$data = $db->query("SELECT * FROM settings");
$info = $db->fetch_array($data);
?>
<!DOCTYPE html>
<html class="full" lang="zh">

    <head>
		<base href="<?php echo $info['URL']; ?>/" />
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>你可以使用我们的API服务创建QY二维码 - <?php echo $info['name']; ?></title>
        <base href="<?php echo $info['URL']; ?>/" />
        <meta charset="utf-8">
        <meta name=keywords content="免费网址缩短,链接高速转发、超长链接缩短，短链加密，自定义短链，短链二维码，短链访问统计，免费短链API，免费二维码API，二维码API调用，个人二维码API搭建，短链平台，高防短链，链接跳转">
        <meta name=description content="免责声明：本站永久免费! 专门提供带统计的短网址服务，短网址均由用户生成，所跳转网站内容均与本站无关! ">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="icon" href="/img/logo.png" />
        <meta name='twitter:url' content='<?php echo $info["URL"]; ?>'>
        <meta name='twitter:title' content='<?php echo $info['name']; ?>'>
        <meta property="og:title" content="<?php echo $info['name']; ?>">

        <!-- Bootstrap core CSS -->
        <link href="css/bootstrap.css" rel="stylesheet">

        <!-- Custom CSS for the Template -->
        <link href="css/style.css" rel="stylesheet">
        <link href="css/animate.css" rel="stylesheet">
        <link href="https://fonts.loli.net/css?family=Fjalla+One" rel="stylesheet">
       
        <style>
            <?php echo $info['cstm-style']; ?>
        </style>
    </head>

    <body>
        <?php
            include "functions/menu.php";
        ?>
        <div class="container">
            <div class="row logo">
                <div class="col-lg-12" style="text-align:center">
                    <?php 
                        include "functions/logo.php";
                        include "functions/darkmode.php";
                    ?>
                </div>
            </div>
        </div>
        <div class="container  animated fadeIn">

            <div class="row" style="margin-top: -25px;">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2 class="modal-title" id="myModalLabel">QY二维码API 开发工具</h2>
                        </div>
                        <div class="modal-body" style="min-height:10%; max-height:350px; overflow-y:scroll; overflow-x:none; position:relative;">
                            
<h1>QY二维码API</h1><hr/><h4>输入参数以继续：</h4><p><b>text</b>：要生成二维码的文本内容（必须）</p><p><b>size</b>：生成二维码大小，单位像素</p><hr/><p><b>示例</b>：<a href="<?php echo $info['URL']; ?>/qr/api.php?text=<?php echo $info['URL']; ?>&size=200" target="_blank"><?php echo $info['URL']; ?>/qr/api.php?text=<?php echo $info['URL']; ?>&size=200</a></p><p><b>html中调用</b>：&lt;img src="<?php echo $info['URL']; ?>/qr/api.php?text=<?php echo $info['URL']; ?>&size=200"&gt;</p>								
                            </div>
                        </div>
                    </div>

                </div><!-- /.modal-content -->
            </div>
        </div>


    </div>
    <!-- JavaScript -->
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.js"></script>

</body>

</html>
